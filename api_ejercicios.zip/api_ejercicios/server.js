const express = require('express');
const cors = require('cors');
const { randomUUID } = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// Estado en memoria
let tareas = [];        // { id:number, titulo:string, completada:boolean }
let productos = [];     // { id:string, nombre:string, categoria:string, precio:number }

// Utilidades
function isNumber(n) { return typeof n === 'number' && !Number.isNaN(n); }
function toScaleName(s) {
  if (s === 'C') return 'Celsius';
  if (s === 'F') return 'Fahrenheit';
  if (s === 'K') return 'Kelvin';
  return s;
}
function convertirTemperatura(valor, desde, hacia) {
  if (desde === hacia) return valor;
  // Convertir primero a Kelvin
  let K;
  if (desde === 'C') K = valor + 273.15;
  else if (desde === 'F') K = (valor - 32) * (5/9) + 273.15;
  else if (desde === 'K') K = valor;
  else throw new Error('Escala "desde" inválida');

  // De Kelvin a destino
  if (hacia === 'C') return K - 273.15;
  if (hacia === 'F') return (K - 273.15) * (9/5) + 32;
  if (hacia === 'K') return K;
  throw new Error('Escala "hacia" inválida');
}
function validarPassword(password) {
  const errores = [];
  if (typeof password !== 'string') errores.push('Password debe ser string');
  if ((password || '').length < 8) errores.push('Mínimo 8 caracteres');
  if (!/[A-Z]/.test(password || '')) errores.push('Al menos una mayúscula');
  if (!/[a-z]/.test(password || '')) errores.push('Al menos una minúscula');
  if (!/[0-9]/.test(password || '')) errores.push('Al menos un número');
  return { esValida: errores.length === 0, errores };
}

// Ejercicio 1: Servicio de Saludo Básico
app.post('/saludo', (req, res) => {
  const { nombre } = req.body;
  if (typeof nombre !== 'string' || !nombre.trim()) {
    return res.status(400).json({ error: 'nombre inválido' });
  }
  res.json({ mensaje: `Hola, ${nombre}` });
});

// Ejercicio 2: Calculadora de Operaciones Básicas
app.post('/calcular', (req, res) => {
  const { a, b, operacion } = req.body;
  if (!isNumber(a) || !isNumber(b)) return res.status(400).json({ error: 'a y b deben ser números' });
  let resultado;
  switch (operacion) {
    case 'suma': resultado = a + b; break;
    case 'resta': resultado = a - b; break;
    case 'multiplicacion': resultado = a * b; break;
    case 'division':
      if (b === 0) return res.status(400).json({ error: 'División por cero' });
      resultado = a / b;
      break;
    default:
      return res.status(400).json({ error: 'operacion inválida' });
  }
  res.json({ resultado });
});

// Ejercicio 3: Gestor de Tareas (CRUD Básico)
// POST /tareas
app.post('/tareas', (req, res) => {
  const { id, titulo, completada } = req.body;
  if (!isNumber(id) || typeof titulo !== 'string' || typeof completada !== 'boolean') {
    return res.status(400).json({ error: 'Formato de tarea inválido' });
  }
  if (tareas.some(t => t.id === id)) return res.status(409).json({ error: 'ID duplicado' });
  const tarea = { id, titulo, completada };
  tareas.push(tarea);
  res.status(201).json(tarea);
});
// GET /tareas
app.get('/tareas', (req, res) => {
  res.json(tareas);
});
// PUT /tareas/:id
app.put('/tareas/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = tareas.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Tarea no encontrada' });
  const { titulo, completada } = req.body;
  if (titulo !== undefined && typeof titulo !== 'string') return res.status(400).json({ error: 'titulo inválido' });
  if (completada !== undefined && typeof completada !== 'boolean') return res.status(400).json({ error: 'completada inválida' });
  tareas[idx] = { ...tareas[idx], ...(titulo !== undefined ? { titulo } : {}), ...(completada !== undefined ? { completada } : {}) };
  res.json(tareas[idx]);
});
// DELETE /tareas/:id
app.delete('/tareas/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = tareas.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Tarea no encontrada' });
  const [eliminada] = tareas.splice(idx, 1);
  res.json(eliminada);
});

// Ejercicio 4: Validador de Contraseñas
app.post('/validar-password', (req, res) => {
  const { password } = req.body;
  const resultado = validarPassword(password);
  res.json(resultado);
});

// Ejercicio 5: Conversor de Temperatura
app.post('/convertir-temperatura', (req, res) => {
  const { valor, desde, hacia } = req.body;
  if (!isNumber(valor)) return res.status(400).json({ error: 'valor debe ser número' });
  if (!['C', 'F', 'K'].includes(desde) || !['C', 'F', 'K'].includes(hacia)) {
    return res.status(400).json({ error: 'Escalas inválidas (usar C|F|K)' });
  }
  try {
    const convertido = convertirTemperatura(valor, desde, hacia);
    res.json({
      valorOriginal: valor,
      valorConvertido: Number(convertido.toFixed(2)),
      escalaOriginal: toScaleName(desde),
      escalaConvertida: toScaleName(hacia),
    });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Ejercicio 6: Buscador en Array
app.post('/buscar', (req, res) => {
  const { array, elemento } = req.body;
  if (!Array.isArray(array)) return res.status(400).json({ error: 'array debe ser arreglo' });
  const indice = array.findIndex(x => {
    // igualdad estricta
    return x === elemento;
  });
  res.json({
    encontrado: indice !== -1,
    indice: indice,
    tipoElemento: typeof elemento
  });
});

// Ejercicio 7: Contador de Palabras
app.post('/contar-palabras', (req, res) => {
  const { texto } = req.body;
  if (typeof texto !== 'string') return res.status(400).json({ error: 'texto debe ser string' });
  const chars = texto.length;
  const tokens = (texto.match(/\b[\p{L}\p{N}’']+\b/gu) || []).map(w => w.toLowerCase());
  const totalPalabras = tokens.length;
  const unicas = new Set(tokens).size;
  res.json({
    totalPalabras,
    totalCaracteres: chars,
    palabrasUnicas: unicas
  });
});

// Ejercicio 8: Generador de Perfiles de Usuario
app.post('/generar-perfil', (req, res) => {
  const { nombre, edad, intereses } = req.body;
  if (typeof nombre !== 'string' || !isNumber(edad) || !Array.isArray(intereses)) {
    return res.status(400).json({ error: 'Formato inválido' });
  }
  let categoria = 'junior';
  if (edad >= 30 && edad < 50) categoria = 'senior';
  else if (edad >= 50) categoria = 'veterano';

  res.json({
    usuario: { nombre, edad, intereses },
    id: randomUUID(),
    fechaCreacion: new Date().toISOString(),
    categoria
  });
});

// Ejercicio 9: Sistema de Calificaciones
app.post('/calcular-promedio', (req, res) => {
  const { calificaciones } = req.body;
  if (!Array.isArray(calificaciones) || calificaciones.some(c => !isNumber(c))) {
    return res.status(400).json({ error: 'calificaciones debe ser arreglo de números' });
  }
  if (calificaciones.some(c => c < 0 || c > 10)) {
    return res.status(400).json({ error: 'Cada calificación debe estar entre 0 y 10' });
  }
  const suma = calificaciones.reduce((acc, c) => acc + c, 0);
  const promedio = calificaciones.length ? (suma / calificaciones.length) : 0;
  const calificacionMasAlta = Math.max(...calificaciones);
  const calificacionMasBaja = Math.min(...calificaciones);
  const estado = promedio >= 6 ? 'aprobado' : 'reprobado';
  res.json({ promedio: Number(promedio.toFixed(2)), calificacionMasAlta, calificacionMasBaja, estado });
});

// Ejercicio 10: API de Productos con Filtros
// POST /productos (agregar)
app.post('/productos', (req, res) => {
  const { nombre, categoria, precio } = req.body;
  if (typeof nombre !== 'string' || typeof categoria !== 'string' || !isNumber(precio)) {
    return res.status(400).json({ error: 'Formato de producto inválido' });
  }
  const prod = { id: randomUUID(), nombre, categoria, precio };
  productos.push(prod);
  res.status(201).json(prod);
});
// GET /productos?categoria=&precioMin=&precioMax=
app.get('/productos', (req, res) => {
  const { categoria, precioMin, precioMax } = req.query;
  let out = [...productos];
  if (categoria) out = out.filter(p => p.categoria === categoria);
  const min = precioMin !== undefined ? Number(precioMin) : undefined;
  const max = precioMax !== undefined ? Number(precioMax) : undefined;
  if (min !== undefined && !Number.isNaN(min)) out = out.filter(p => p.precio >= min);
  if (max !== undefined && !Number.isNaN(max)) out = out.filter(p => p.precio <= max);
  res.json(out);
});

// Arranque
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API escuchando en http://localhost:${PORT}`);
});