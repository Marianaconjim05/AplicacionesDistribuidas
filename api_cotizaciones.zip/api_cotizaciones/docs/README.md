# API Cotizaciones - Segunda Práctica

## Descripción
Servicios web que obtienen la cotización de la Libra Esterlina (GBP) mediante web scraping y aplican un ajuste del 10%:
- **Compra (usuario compra GBP):** precio mercado -10%
- **Venta (usuario vende GBP):** precio mercado +10%

## Cómo correr
```bash
npm install
npm start