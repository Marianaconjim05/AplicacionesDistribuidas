const express = require("express");
const { obtenerLibra } = require("./scraper");

const app = express();
const PORT = 3000;

// ===== PÁGINA PRINCIPAL =====
app.get("/", async (req, res) => {
  try {
    const valor = await obtenerLibra();
    const compra = (valor * 0.9).toFixed(4);
    const venta = (valor * 1.1).toFixed(4);

    res.send(`
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>La Mejor Cotización</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Segoe UI", sans-serif;
    }

    body {
      height: 100vh;
      background: linear-gradient(135deg, #1e3c72, #2a5298);
      display: flex;
      justify-content: center;
      align-items: center;
      color: white;
    }

    .container {
      text-align: center;
      background: rgba(255, 255, 255, 0.15);
      padding: 60px;
      border-radius: 20px;
      backdrop-filter: blur(10px);
      box-shadow: 0 20px 40px rgba(0,0,0,0.3);
      width: 500px;
    }

    h1 {
      font-size: 38px;
      margin-bottom: 15px;
    }

    h2 {
      font-size: 22px;
      font-weight: 300;
      margin-bottom: 40px;
    }

    .precio {
      font-size: 30px;
      margin: 20px 0;
      padding: 20px;
      border-radius: 12px;
    }

    .compra {
      background: rgba(0, 255, 0, 0.2);
      border: 2px solid #00ff99;
    }

    .venta {
      background: rgba(0, 153, 255, 0.2);
      border: 2px solid #00b7ff;
    }

    footer {
      margin-top: 30px;
      font-size: 14px;
      opacity: 0.8;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>💷 Libra Esterlina</h1>
    <h2>LaMejorCotizacion</h2>

    <div class="precio compra">
      🟢 COMPRA <br>
      ${compra}
    </div>

    <div class="precio venta">
      🔵 VENTA <br>
      ${venta}
    </div>

    <footer>
      Valores ajustados ±10% <br>
      Servicio Web con Web Scraping
    </footer>
  </div>
</body>
</html>
    `);

  } catch (error) {
    res.send("Error al obtener cotización");
  }
});

// ===== SERVICIO COMPRA JSON =====
app.get("/compra", async (req, res) => {
  const valor = await obtenerLibra();
  res.json({
    moneda: "Libra Esterlina",
    tipo: "Compra",
    valor: (valor * 0.9).toFixed(4)
  });
});

// ===== SERVICIO VENTA JSON =====
app.get("/venta", async (req, res) => {
  const valor = await obtenerLibra();
  res.json({
    moneda: "Libra Esterlina",
    tipo: "Venta",
    valor: (valor * 1.1).toFixed(4)
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor activo en http://localhost:${PORT}`);
});
