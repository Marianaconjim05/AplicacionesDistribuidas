const axios = require("axios");
const cheerio = require("cheerio");

async function obtenerLibra() {
  const url = "https://www.x-rates.com/table/?from=GBP&amount=1";

  const { data } = await axios.get(url);
  const $ = cheerio.load(data);

  // Tomamos el valor frente al USD como referencia
  const valor = $("table.tablesorter.ratesTable tbody tr")
    .first()
    .find("td")
    .eq(1)
    .text();

  return parseFloat(valor);
}

module.exports = { obtenerLibra };
