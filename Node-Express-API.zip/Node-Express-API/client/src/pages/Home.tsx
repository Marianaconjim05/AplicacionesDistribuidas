import { useItems } from "@/hooks/use-items";
import { CreateItemDialog } from "@/components/CreateItemDialog";
import { ItemCard } from "@/components/ItemCard";
import { Loader2, PackageOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

export default function Home() {
  const { data: items, isLoading, error } = useItems();
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const filteredItems = items?.filter(item => {
    if (filter === 'active') return !item.completed;
    if (filter === 'completed') return item.completed;
    return true;
  });

  const activeCount = items?.filter(i => !i.completed).length ?? 0;
  const completedCount = items?.filter(i => i.completed).length ?? 0;

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center space-y-4 max-w-md mx-auto">
          <div className="text-destructive font-bold text-xl">Something went wrong</div>
          <p className="text-muted-foreground">{error.message}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50/50 dark:bg-background/95">
      {/* Decorative background element */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[100px]" />
        <div className="absolute top-[20%] -left-[10%] w-[40%] h-[40%] rounded-full bg-blue-500/5 blur-[100px]" />
      </div>

      <div className="container max-w-5xl mx-auto px-4 py-12 sm:py-20">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="space-y-2">
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-foreground">
              Dashboard
            </h1>
            <p className="text-lg text-muted-foreground max-w-md">
              Manage your tasks and projects with elegance and simplicity.
            </p>
          </div>
          <CreateItemDialog />
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-8 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
          <FilterButton 
            active={filter === 'all'} 
            onClick={() => setFilter('all')}
            count={items?.length}
          >
            All
          </FilterButton>
          <FilterButton 
            active={filter === 'active'} 
            onClick={() => setFilter('active')}
            count={activeCount}
          >
            Active
          </FilterButton>
          <FilterButton 
            active={filter === 'completed'} 
            onClick={() => setFilter('completed')}
            count={completedCount}
          >
            Completed
          </FilterButton>
        </div>

        {/* Content Area */}
        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-10 h-10 text-primary animate-spin" />
          </div>
        ) : filteredItems?.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-card border border-dashed border-border rounded-3xl animate-in fade-in zoom-in-95 duration-500">
            <div className="bg-muted/50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <PackageOpen className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">No items found</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-6">
              {filter === 'all' 
                ? "You haven't created any items yet. Start by adding your first task." 
                : `No ${filter} items to display.`}
            </p>
            {filter === 'all' && <CreateItemDialog />}
          </div>
        ) : (
          <div className="grid gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            {filteredItems?.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function FilterButton({ 
  children, 
  active, 
  onClick, 
  count 
}: { 
  children: React.ReactNode; 
  active: boolean; 
  onClick: () => void;
  count?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 flex items-center gap-2",
        active 
          ? "bg-foreground text-background shadow-lg" 
          : "bg-white dark:bg-muted text-muted-foreground hover:bg-gray-100 dark:hover:bg-muted/80 hover:text-foreground"
      )}
    >
      {children}
      {count !== undefined && (
        <span className={cn(
          "px-1.5 py-0.5 rounded-md text-xs",
          active ? "bg-background/20 text-background" : "bg-black/5 dark:bg-white/10"
        )}>
          {count}
        </span>
      )}
    </button>
  );
}
