import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { ItemForm } from "./ItemForm";
import { useState } from "react";

export function CreateItemDialog() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-300">
          <Plus className="mr-2 h-5 w-5" />
          New Item
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-2xl p-6 border-0 shadow-2xl">
        <DialogHeader className="mb-4">
          <DialogTitle className="text-2xl font-display font-bold text-foreground">Create New Item</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Add a new item to your dashboard. Fill out the details below.
          </DialogDescription>
        </DialogHeader>
        <ItemForm onSuccess={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}
