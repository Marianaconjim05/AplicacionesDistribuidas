import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Pencil } from "lucide-react";
import { ItemForm } from "./ItemForm";
import { useState } from "react";
import { type Item } from "@shared/schema";

interface EditItemDialogProps {
  item: Item;
}

export function EditItemDialog({ item }: EditItemDialogProps) {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg hover:bg-primary/10 hover:text-primary transition-colors">
          <Pencil className="h-4 w-4" />
          <span className="sr-only">Edit</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-2xl p-6 border-0 shadow-2xl">
        <DialogHeader className="mb-4">
          <DialogTitle className="text-2xl font-display font-bold text-foreground">Edit Item</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Make changes to your item here. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <ItemForm item={item} onSuccess={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}
