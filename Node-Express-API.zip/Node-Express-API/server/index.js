const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// =======================
// SERVICIOS WEB
// =======================

// mascaracteres
app.post("/mascaracteres", (req, res) => {
  const { cad1, cad2 } = req.body;

  if (!cad1 || !cad2) {
    return res.json({ ok: false, error: "Faltan parámetros" });
  }

  const resultado = cad1.length >= cad2.length ? cad1 : cad2;
  res.json({ ok: true, resultado });
});

// menoscaracteres
app.post("/menoscaracteres", (req, res) => {
  const { cad1, cad2 } = req.body;

  if (!cad1 || !cad2) {
    return res.json({ ok: false, error: "Faltan parámetros" });
  }

  const resultado = cad1.length <= cad2.length ? cad1 : cad2;
  res.json({ ok: true, resultado });
});

// numcaracteres
app.post("/numcaracteres", (req, res) => {
  const { cadena } = req.body;

  if (!cadena) {
    return res.json({ ok: false, error: "No se envió cadena" });
  }

  res.json({ ok: true, resultado: cadena.length });
});

// palindroma
app.post("/palindroma", (req, res) => {
  const { cadena } = req.body;

  if (!cadena) {
    return res.json({ ok: false, error: "No se envió cadena" });
  }

  const limpia = cadena.toLowerCase().replace(/[^a-z0-9]/g, "");
  const invertida = limpia.split("").reverse().join("");

  res.json({ ok: true, resultado: limpia === invertida });
});

// concat
app.post("/concat", (req, res) => {
  const { cad1, cad2 } = req.body;

  if (!cad1 || !cad2) {
    return res.json({ ok: false, error: "Faltan parámetros" });
  }

  res.json({ ok: true, resultado: cad1 + cad2 });
});

// applysha256
app.post("/applysha256", (req, res) => {
  const { cadena } = req.body;

  if (!cadena) {
    return res.json({ ok: false, error: "No se envió cadena" });
  }

  const hash = crypto.createHash("sha256").update(cadena).digest("hex");

  res.json({
    ok: true,
    original: cadena,
    sha256: hash,
  });
});

// verifysha256
app.post("/verifysha256", (req, res) => {
  const { original, encriptada } = req.body;

  if (!original || !encriptada) {
    return res.json({ ok: false, error: "Faltan parámetros" });
  }

  const hash = crypto.createHash("sha256").update(original).digest("hex");

  res.json({
    ok: true,
    resultado: hash === encriptada,
  });
});

// =======================

app.listen(PORT, () => {
  console.log("Servidor activo en puerto " + PORT);
});
