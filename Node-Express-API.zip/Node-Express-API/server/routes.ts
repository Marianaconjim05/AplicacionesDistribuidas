import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // GET /api/items
  app.get(api.items.list.path, async (req, res) => {
    const items = await storage.getItems();
    res.json(items);
  });

  // GET /api/items/:id
  app.get(api.items.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(404).json({ message: "Invalid ID" });
    
    const item = await storage.getItem(id);
    if (!item) {
      return res.status(404).json({ message: "Item not found" });
    }
    res.json(item);
  });

  // POST /api/items
  app.post(api.items.create.path, async (req, res) => {
    try {
      const input = api.items.create.input.parse(req.body);
      const item = await storage.createItem(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // PUT /api/items/:id
  app.put(api.items.update.path, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(404).json({ message: "Invalid ID" });

    try {
      const input = api.items.update.input.parse(req.body);
      const existing = await storage.getItem(id);
      if (!existing) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      const updated = await storage.updateItem(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // DELETE /api/items/:id
  app.delete(api.items.delete.path, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(404).json({ message: "Invalid ID" });

    const existing = await storage.getItem(id);
    if (!existing) {
      return res.status(404).json({ message: "Item not found" });
    }

    await storage.deleteItem(id);
    res.status(204).send();
  });

  // Seed data if empty
  const existing = await storage.getItems();
  if (existing.length === 0) {
    await storage.createItem({ name: "Setup API", description: "Create schema and routes", completed: true });
    await storage.createItem({ name: "Frontend", description: "Generate React dashboard", completed: false });
    await storage.createItem({ name: "Test endpoints", description: "Verify all CRUD operations", completed: false });
  }

  return httpServer;
}
