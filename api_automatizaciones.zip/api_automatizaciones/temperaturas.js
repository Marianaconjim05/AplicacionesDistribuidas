const axios = require("axios");
const nodemailer = require("nodemailer");
const TelegramBot = require("node-telegram-bot-api");

// ===== VARIABLES =====
let contadorAlto = 0;

// ===== TELEGRAM =====
const TELEGRAM_TOKEN = "8216202618:AAHrCylSLbtDymZH0plHK3czqERrrMVFYCw";
const CHAT_ID = "8130803355";
const bot = new TelegramBot(TELEGRAM_TOKEN);


// ===== FUNCIÓN PRINCIPAL =====
async function obtenerTemperatura() {
  try {
    const response = await axios.get(
      "https://www.randomnumberapi.com/api/v1.0/random?min=15&max=45&count=1"
    );

    const temperatura = response.data[0];
    console.log("🌡️ Temperatura:", temperatura);

    if (temperatura > 30) {
      contadorAlto++;
      console.log(`⚠️ Alta consecutiva: ${contadorAlto}`);
    } else {
      contadorAlto = 0;
    }

    if (contadorAlto === 3) {
      enviarCorreo(temperatura);
      enviarTelegram(temperatura);
      contadorAlto = 0;
    }

  } catch (error) {
    console.error("Error al obtener temperatura", error.message);
  }
}

// ===== EJECUCIÓN CADA 30s =====
setInterval(obtenerTemperatura, 1000);
